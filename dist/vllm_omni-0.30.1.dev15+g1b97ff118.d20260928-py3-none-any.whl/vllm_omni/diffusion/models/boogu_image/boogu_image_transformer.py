# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
#
# Native vLLM-Omni port of the Boogu-Image transformer.
#
# Ported from the upstream `boogu` package
# (boogu/models/transformers/transformer_boogu.py and friends) with the
# following changes:
#   - Diffusers mixins (ModelMixin/ConfigMixin/PeftAdapterMixin) removed;
#     configuration is read from `od_config.tf_model_config`.
#   - diffusers Attention + custom processors replaced by the vLLM-Omni
#     `Attention` layer (backend/SP/KV-quant handled by the framework).
#   - Q/K/V and FFN projections use vLLM parallel linears for TP support.
#   - Training-time features (prompt tuning, gradient checkpointing) and
#     inference caches (TeaCache/TaylorSeer) are not ported.

import itertools
from collections import defaultdict
from collections.abc import Iterable
from typing import TYPE_CHECKING

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers.models.embeddings import Timesteps, get_1d_rotary_pos_embed
from einops import rearrange, repeat
from vllm.logger import init_logger
from vllm.model_executor.layers.linear import (
    MergedColumnParallelLinear,
    QKVParallelLinear,
    ReplicatedLinear,
    RowParallelLinear,
)
from vllm.model_executor.model_loader.weight_utils import default_weight_loader
from vllm.platforms import current_platform
from vllm.triton_utils import HAS_TRITON

from vllm_omni.diffusion.attention.backends.abstract import AttentionMetadata
from vllm_omni.diffusion.attention.layer import Attention
from vllm_omni.diffusion.data import OmniDiffusionConfig
from vllm_omni.diffusion.distributed.sp_plan import (
    SequenceParallelInput,
    SequenceParallelOutput,
)
from vllm_omni.diffusion.layers.fused_qk_norm_rope import (
    _fused_cuda_supported,
    fused_qk_norm_rope,
    fused_qk_norm_rope_min_tokens,
)
from vllm_omni.diffusion.layers.norm import RMSNorm
from vllm_omni.diffusion.models.boogu_image.sp_layout import (
    RotaryEmbedding,
    ShardLayout,
    pack_local_rotary,
    rank_concat_mask_or_none,
)
from vllm_omni.platforms import current_omni_platform

if TYPE_CHECKING:
    from vllm.model_executor.layers.quantization.base_config import QuantizationConfig

logger = init_logger(__name__)

RotaryFrequencyTables = list[RotaryEmbedding]


def _join_prefix(prefix: str, name: str) -> str:
    return f"{prefix}.{name}" if prefix else name


def apply_rotary_emb(x: torch.Tensor, rotary_emb: RotaryEmbedding) -> torch.Tensor:
    """Apply rotary embeddings with real-valued cosine and sine tensors.

    Args:
        x: Query or key tensor of shape [B, S, H, D].
        rotary_emb: Cosine and sine tensors, each shaped [B, S, D]. The tuple
            may carry a third element (the packed table for the fused
            qk-norm+RoPE path); it is ignored here, hence the indexed access
            instead of tuple unpacking.
    """
    freqs_cos, freqs_sin = rotary_emb[0], rotary_emb[1]
    freqs_cos = freqs_cos.unsqueeze(2)
    freqs_sin = freqs_sin.unsqueeze(2)

    # The frequency values are repeated for each adjacent channel pair. This
    # is the real-valued equivalent of multiplying view_as_complex(x) by cis.
    x_float = x.float()
    x_even = x_float[..., ::2]
    x_odd = x_float[..., 1::2]
    cos = freqs_cos[..., ::2]
    sin = freqs_sin[..., ::2]
    x_out = torch.stack((x_even * cos - x_odd * sin, x_even * sin + x_odd * cos), dim=-1).flatten(3)
    return x_out.type_as(x)


# The fused qk-norm+RoPE path is always on where the fast path exists; on
# other platforms the eager chain below is the behaviour-identical fallback.
_FUSED_QK_NORM_ROPE = HAS_TRITON and current_platform.is_cuda()

# Boogu's default for the fused-path token gate: fuse only when a rotary table
# spans at least this many positions (counted as B*S). Below the crossover a
# request is host-bound and the fused path's per-call Python launch (custom-op
# impl + Triton launcher) can cost more end-to-end than the kernel saves.
# Measured on one H200: on the pre-#6871 main, 512^2 (1.1k tokens) paid
# +191 ms/request and the crossover sat at ~2,350 tokens; on the current main
# the 512^2 family measures as noise (+/-25 ms, sign-inconsistent) while
# >=768^2 (2.3k tokens) gains. The crossover is host-dependent — re-benchmark
# on your hardware and override with VLLM_OMNI_FUSED_QK_NORM_ROPE_MIN_TOKENS
# (0 = always fuse); see fused_qk_norm_rope_min_tokens().
_FUSED_MIN_TOKENS = 2048


def _with_packed_rope_table(rotary_emb: RotaryEmbedding) -> RotaryEmbedding:
    """Append the packed fp32 table the fused qk-norm+RoPE op consumes.

    ``freqs_cos``/``freqs_sin`` are theta-repeat-interleaved ``[B, S, D]``
    (``cos[2i] == cos[2i+1] == cos(theta_i)``), so taking every even column
    yields the theta-width halves and the packed table is
    ``[B*S, D] = [cos(theta) | sin(theta)]``. Tables spanning fewer positions
    (counted as ``B*S``) than the token gate — Boogu's ``_FUSED_MIN_TOKENS``
    default, overridable through ``VLLM_OMNI_FUSED_QK_NORM_ROPE_MIN_TOKENS``
    (``0`` = always fuse) — are returned unchanged: without the third element
    every consumer stays on the eager chain (this also keeps short tables like
    the context refiner's off the fused path).
    """
    freqs_cos, freqs_sin = rotary_emb[0], rotary_emb[1]
    if freqs_cos.shape[0] * freqs_cos.shape[1] < fused_qk_norm_rope_min_tokens(_FUSED_MIN_TOKENS):
        return rotary_emb
    packed = torch.cat((freqs_cos[..., ::2], freqs_sin[..., ::2]), dim=-1)
    return freqs_cos, freqs_sin, packed.reshape(-1, freqs_cos.shape[-1]).float()


def _qk_norm_rope(
    query: torch.Tensor,
    key: torch.Tensor,
    norm_q,
    norm_k,
    rotary_emb: RotaryEmbedding | None,
    dtype: torch.dtype,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Per-head Q/K RMSNorm + RoPE + cast, fused into one kernel launch when
    a packed rope table is present; otherwise the original eager chain."""
    # Gate on the op's own fast-path predicate: when the fused CUDA kernel
    # cannot run (dtype, device, or geometry outside even
    # rotary_dim <= head_dim <= 256), the original chain below must be used
    # bit-exactly rather than the op's internal eager fallback, whose rounding
    # differs from vLLM's RMSNorm by one ulp on a fraction of elements.
    if (
        rotary_emb is not None
        and len(rotary_emb) > 2
        and rotary_emb[2] is not None
        and _fused_cuda_supported(query, key, query.shape[-1], query.shape[-1], interleaved=True)
    ):
        batch, seq_len, num_heads, head_dim = query.shape
        num_kv_heads = key.shape[2]
        fused_q, fused_k = fused_qk_norm_rope(
            query.view(batch * seq_len, num_heads, head_dim),
            key.view(batch * seq_len, num_kv_heads, head_dim),
            norm_q.weight,
            norm_k.weight,
            rotary_emb[2],
            norm_q.variance_epsilon,
            interleaved=True,
        )
        return (
            fused_q.view(batch, seq_len, num_heads, head_dim),
            fused_k.view(batch, seq_len, num_kv_heads, head_dim),
        )
    query = norm_q(query)
    key = norm_k(key)
    if rotary_emb is not None:
        query = apply_rotary_emb(query, rotary_emb)
        key = apply_rotary_emb(key, rotary_emb)
    return query.to(dtype), key.to(dtype)


def swiglu(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    return F.silu(x.float(), inplace=False).to(x.dtype) * y


class TimestepEmbedding(nn.Module):
    def __init__(self, in_channels: int, time_embed_dim: int) -> None:
        super().__init__()
        self.linear_1 = nn.Linear(in_channels, time_embed_dim, bias=True)
        self.act = nn.SiLU()
        self.linear_2 = nn.Linear(time_embed_dim, time_embed_dim, bias=True)

    def forward(self, sample: torch.Tensor) -> torch.Tensor:
        return self.linear_2(self.act(self.linear_1(sample)))


class LuminaRMSNormZero(nn.Module):
    """AdaRMS modulation: projects `temb` into scale/gate terms."""

    def __init__(
        self,
        embedding_dim: int,
        norm_eps: float,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.silu = nn.SiLU()
        self.linear = ReplicatedLinear(
            min(embedding_dim, 1024),
            4 * embedding_dim,
            bias=True,
            return_bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "linear"),
        )
        self.norm = RMSNorm(embedding_dim, eps=norm_eps)

    def forward(
        self, x: torch.Tensor, emb: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        emb = self.linear(self.silu(emb))
        scale_msa, gate_msa, scale_mlp, gate_mlp = emb.chunk(4, dim=1)
        x = self.norm(x) * (1 + scale_msa[:, None])
        return x, gate_msa, scale_mlp, gate_mlp


class LuminaLayerNormContinuous(nn.Module):
    """Final AdaLN + optional output projection (upstream `norm_out`)."""

    def __init__(
        self,
        embedding_dim: int,
        conditioning_embedding_dim: int,
        elementwise_affine: bool = True,
        eps: float = 1e-5,
        bias: bool = True,
        out_dim: int | None = None,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.silu = nn.SiLU()
        self.linear_1 = ReplicatedLinear(
            conditioning_embedding_dim,
            embedding_dim,
            bias=bias,
            return_bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "linear_1"),
        )
        self.norm = nn.LayerNorm(embedding_dim, eps, elementwise_affine, bias)
        self.linear_2 = (
            ReplicatedLinear(
                embedding_dim,
                out_dim,
                bias=bias,
                return_bias=False,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "linear_2"),
            )
            if out_dim is not None
            else None
        )

    def forward(self, x: torch.Tensor, conditioning_embedding: torch.Tensor) -> torch.Tensor:
        scale = self.linear_1(self.silu(conditioning_embedding).to(x.dtype))
        x = self.norm(x) * (1 + scale)[:, None, :]
        if self.linear_2 is not None:
            x = self.linear_2(x)
        return x


class LuminaFeedForward(nn.Module):
    """SwiGLU feed-forward with tensor-parallel projections.

    The ``gate`` and ``input`` projections are fused into a single
    ``MergedColumnParallelLinear`` (one GEMM instead of two), matching the
    ``gate_up_proj`` convention used by the Hunyuan Image 3 port. The SwiGLU
    activation keeps its float32 computation for numerical parity with
    upstream.
    """

    def __init__(
        self,
        dim: int,
        inner_dim: int,
        multiple_of: int = 256,
        ffn_dim_multiplier: float | None = None,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        if ffn_dim_multiplier is not None:
            inner_dim = int(ffn_dim_multiplier * inner_dim)
        inner_dim = multiple_of * ((inner_dim + multiple_of - 1) // multiple_of)

        self.gate_up_proj = MergedColumnParallelLinear(
            input_size=dim,
            output_sizes=[inner_dim, inner_dim],
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "gate_up_proj"),
        )
        self.linear_2 = RowParallelLinear(
            inner_dim,
            dim,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "linear_2"),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gate_up, _ = self.gate_up_proj(x)
        h1, h2 = gate_up.chunk(2, dim=-1)
        out, _ = self.linear_2(swiglu(h1, h2))
        return out


class Lumina2CombinedTimestepCaptionEmbedding(nn.Module):
    def __init__(
        self,
        hidden_size: int = 4096,
        instruction_feat_dim: int = 2048,
        frequency_embedding_size: int = 256,
        norm_eps: float = 1e-5,
        timestep_scale: float = 1.0,
    ) -> None:
        super().__init__()
        self.time_proj = Timesteps(
            num_channels=frequency_embedding_size,
            flip_sin_to_cos=True,
            downscale_freq_shift=0.0,
            scale=timestep_scale,
        )
        self.timestep_embedder = TimestepEmbedding(
            in_channels=frequency_embedding_size, time_embed_dim=min(hidden_size, 1024)
        )
        self.caption_embedder = nn.Sequential(
            RMSNorm(instruction_feat_dim, eps=norm_eps),
            nn.Linear(instruction_feat_dim, hidden_size, bias=True),
        )

    def forward(
        self,
        timestep: torch.Tensor,
        instruction_hidden_states: torch.Tensor,
        dtype: torch.dtype,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        timestep_proj = self.time_proj(timestep).to(dtype=dtype)
        time_embed = self.timestep_embedder(timestep_proj)
        caption_embed = self.caption_embedder(instruction_hidden_states)
        return time_embed, caption_embed


class BooguImageDoubleStreamRotaryPosEmbed(nn.Module):
    """3-axis RoPE producing real-valued per-segment embeddings.

    Returns separate frequency tensors for instruction tokens, reference-image
    tokens, noise-image tokens, the full joint sequence, and the combined
    (ref + noise) image sequence used by the double-stream blocks.
    """

    def __init__(
        self,
        theta: int,
        axes_dim: tuple[int, int, int],
        axes_lens: tuple[int, int, int] = (300, 512, 512),
        patch_size: int = 2,
    ) -> None:
        super().__init__()
        self.theta = theta
        self.axes_dim = axes_dim
        self.axes_lens = axes_lens
        self.patch_size = patch_size

    @staticmethod
    def get_freqs_real(
        axes_dim: tuple[int, int, int], axes_lens: tuple[int, int, int], theta: int
    ) -> RotaryFrequencyTables:
        freqs_real = []
        # Ascend supports real-valued gather but float32 avoids routing the
        # entire RoPE path through slower and less broadly supported float64
        # kernels. MPS also requires float32 because it does not support
        # float64. Other platforms retain the previous precision where valid.
        freqs_dtype = (
            torch.float32
            if (
                current_omni_platform.is_npu()
                or not current_omni_platform.supports_float64()
                or torch.backends.mps.is_available()
            )
            else torch.float64
        )
        for d, e in zip(axes_dim, axes_lens):
            freqs_cos, freqs_sin = get_1d_rotary_pos_embed(
                d,
                e,
                theta=theta,
                use_real=True,
                repeat_interleave_real=True,
                freqs_dtype=freqs_dtype,
            )
            freqs_real.append((freqs_cos, freqs_sin))
        return freqs_real

    def _get_freqs_real(self, freqs_real: RotaryFrequencyTables, ids: torch.Tensor) -> RotaryEmbedding:
        device = ids.device
        if ids.device.type == "mps":
            ids = ids.to("cpu")

        cos_result = []
        sin_result = []
        for i in range(len(self.axes_dim)):
            freqs_cos, freqs_sin = freqs_real[i]
            freqs_cos = freqs_cos.to(ids.device)
            freqs_sin = freqs_sin.to(ids.device)
            index = ids[:, :, i : i + 1].repeat(1, 1, freqs_cos.shape[-1]).to(torch.int64)
            cos_result.append(torch.gather(freqs_cos.unsqueeze(0).repeat(index.shape[0], 1, 1), dim=1, index=index))
            sin_result.append(torch.gather(freqs_sin.unsqueeze(0).repeat(index.shape[0], 1, 1), dim=1, index=index))
        return torch.cat(cos_result, dim=-1).to(device), torch.cat(sin_result, dim=-1).to(device)

    def forward(
        self,
        freqs_real: RotaryFrequencyTables,
        attention_mask: torch.Tensor,
        l_effective_ref_img_len: list[list[int]],
        l_effective_img_len: list[int],
        ref_img_sizes: list[list[tuple[int, int]] | None],
        img_sizes: list[tuple[int, int]],
        device: torch.device,
    ):
        batch_size = len(attention_mask)
        p = self.patch_size

        encoder_seq_len = attention_mask.shape[1]
        l_effective_cap_len = attention_mask.sum(dim=1).tolist()

        seq_lengths = [
            cap_len + sum(ref_img_len) + img_len
            for cap_len, ref_img_len, img_len in zip(l_effective_cap_len, l_effective_ref_img_len, l_effective_img_len)
        ]

        max_seq_len = max(seq_lengths)
        max_ref_img_len = max(sum(ref_img_len) for ref_img_len in l_effective_ref_img_len)
        max_img_len = max(l_effective_img_len)

        position_ids = torch.zeros(batch_size, max_seq_len, 3, dtype=torch.int32, device=device)

        for i, (cap_seq_len, seq_len) in enumerate(zip(l_effective_cap_len, seq_lengths)):
            position_ids[i, :cap_seq_len] = repeat(
                torch.arange(cap_seq_len, dtype=torch.int32, device=device), "l -> l 3"
            )

            pe_shift = cap_seq_len
            pe_shift_len = cap_seq_len

            if ref_img_sizes[i] is not None:
                for ref_img_size, ref_img_len in zip(ref_img_sizes[i], l_effective_ref_img_len[i]):
                    H, W = ref_img_size
                    ref_H_tokens, ref_W_tokens = H // p, W // p
                    assert ref_H_tokens * ref_W_tokens == ref_img_len

                    row_ids = repeat(
                        torch.arange(ref_H_tokens, dtype=torch.int32, device=device),
                        "h -> h w",
                        w=ref_W_tokens,
                    ).flatten()
                    col_ids = repeat(
                        torch.arange(ref_W_tokens, dtype=torch.int32, device=device),
                        "w -> h w",
                        h=ref_H_tokens,
                    ).flatten()
                    position_ids[i, pe_shift_len : pe_shift_len + ref_img_len, 0] = pe_shift
                    position_ids[i, pe_shift_len : pe_shift_len + ref_img_len, 1] = row_ids
                    position_ids[i, pe_shift_len : pe_shift_len + ref_img_len, 2] = col_ids

                    pe_shift += max(ref_H_tokens, ref_W_tokens)
                    pe_shift_len += ref_img_len

            H, W = img_sizes[i]
            H_tokens, W_tokens = H // p, W // p
            assert H_tokens * W_tokens == l_effective_img_len[i]

            row_ids = repeat(torch.arange(H_tokens, dtype=torch.int32, device=device), "h -> h w", w=W_tokens).flatten()
            col_ids = repeat(torch.arange(W_tokens, dtype=torch.int32, device=device), "w -> h w", h=H_tokens).flatten()

            assert pe_shift_len + l_effective_img_len[i] == seq_len
            position_ids[i, pe_shift_len:seq_len, 0] = pe_shift
            position_ids[i, pe_shift_len:seq_len, 1] = row_ids
            position_ids[i, pe_shift_len:seq_len, 2] = col_ids

        freqs_cos, freqs_sin = self._get_freqs_real(freqs_real, position_ids)

        def empty_rotary_emb(seq_len: int) -> RotaryEmbedding:
            shape = (batch_size, seq_len, freqs_cos.shape[-1])
            return (
                torch.zeros(shape, device=device, dtype=freqs_cos.dtype),
                torch.zeros(shape, device=device, dtype=freqs_sin.dtype),
            )

        cap_rotary_emb = empty_rotary_emb(encoder_seq_len)
        ref_img_rotary_emb = empty_rotary_emb(max_ref_img_len)
        img_rotary_emb = empty_rotary_emb(max_img_len)

        combined_img_seq_lengths = [
            sum(ref_img_len) + img_len for ref_img_len, img_len in zip(l_effective_ref_img_len, l_effective_img_len)
        ]
        max_combined_img_len = max(combined_img_seq_lengths)

        combined_img_rotary_emb = empty_rotary_emb(max_combined_img_len)

        for i, (cap_seq_len, ref_img_len, img_len, seq_len) in enumerate(
            zip(l_effective_cap_len, l_effective_ref_img_len, l_effective_img_len, seq_lengths)
        ):
            ref_len = sum(ref_img_len)
            img_start = cap_seq_len + ref_len
            for source, cap_target, ref_target, img_target, combined_target in zip(
                (freqs_cos, freqs_sin),
                cap_rotary_emb,
                ref_img_rotary_emb,
                img_rotary_emb,
                combined_img_rotary_emb,
            ):
                cap_target[i, :cap_seq_len] = source[i, :cap_seq_len]
                ref_target[i, :ref_len] = source[i, cap_seq_len:img_start]
                img_target[i, :img_len] = source[i, img_start : img_start + img_len]
                combined_target[i, :ref_len] = source[i, cap_seq_len:img_start]
                combined_target[i, ref_len : ref_len + img_len] = source[i, img_start : img_start + img_len]

        return (
            cap_rotary_emb,
            ref_img_rotary_emb,
            img_rotary_emb,
            (freqs_cos, freqs_sin),
            l_effective_cap_len,
            seq_lengths,
            combined_img_rotary_emb,
            combined_img_seq_lengths,
        )


def _concat_instruction_image_features(
    img_tensors: list[torch.Tensor],
    instruct_tensors: list[torch.Tensor],
    encoder_seq_lengths: list[int],
    seq_lengths: list[int],
) -> list[torch.Tensor]:
    """Pack per-stream tensors into joint sequences (instruction first, then image)."""
    assert len(img_tensors) == len(instruct_tensors)

    batch_size = img_tensors[0].shape[0]
    joint_capacity = instruct_tensors[0].shape[1] + img_tensors[0].shape[1]

    concatenated_list = []
    for img_tensor, instruct_tensor in zip(img_tensors, instruct_tensors):
        feature_dim = img_tensor.shape[-1]
        concatenated = img_tensor.new_zeros(
            batch_size,
            joint_capacity,
            feature_dim,
        )
        for i, (encoder_seq_len, seq_len) in enumerate(zip(encoder_seq_lengths, seq_lengths)):
            concatenated[i, :encoder_seq_len] = instruct_tensor[i, :encoder_seq_len]
            concatenated[i, encoder_seq_len:seq_len] = img_tensor[i, : seq_len - encoder_seq_len]
        concatenated_list.append(concatenated)

    return concatenated_list


def _split_instruction_image_features(
    hidden_states: torch.Tensor,
    encoder_seq_lengths: list[int],
    seq_lengths: list[int],
    *,
    instruct_capacity: int,
    img_capacity: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Unpack a joint sequence back into (instruction, image) streams."""
    batch_size = hidden_states.shape[0]
    feature_dim = hidden_states.shape[-1]

    instruct_hidden_states = hidden_states.new_zeros(
        batch_size,
        instruct_capacity,
        feature_dim,
    )
    img_hidden_states = hidden_states.new_zeros(
        batch_size,
        img_capacity,
        feature_dim,
    )

    for i, (encoder_seq_len, seq_len) in enumerate(zip(encoder_seq_lengths, seq_lengths)):
        img_len = seq_len - encoder_seq_len
        instruct_hidden_states[i, :encoder_seq_len] = hidden_states[i, :encoder_seq_len]
        img_hidden_states[i, :img_len] = hidden_states[i, encoder_seq_len:seq_len]

    return instruct_hidden_states, img_hidden_states


class BooguImageSelfAttention(nn.Module):
    """GQA self-attention with QK RMSNorm and real-valued RoPE.

    Replaces the upstream diffusers `Attention` + Boogu attention processors;
    the vLLM-Omni `Attention` layer picks the kernel backend and handles
    SP/KV-cache concerns.
    """

    def __init__(
        self,
        dim: int,
        num_attention_heads: int,
        num_kv_heads: int,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.head_dim = dim // num_attention_heads

        self.to_qkv = QKVParallelLinear(
            hidden_size=dim,
            head_size=self.head_dim,
            total_num_heads=num_attention_heads,
            total_num_kv_heads=num_kv_heads,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "to_qkv"),
        )
        self.norm_q = RMSNorm(self.head_dim, eps=1e-5)
        self.norm_k = RMSNorm(self.head_dim, eps=1e-5)
        self.to_out = RowParallelLinear(
            dim,
            dim,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "to_out"),
        )

        self.num_local_heads = self.to_qkv.num_heads
        self.num_local_kv_heads = self.to_qkv.num_kv_heads
        self.q_size = self.num_local_heads * self.head_dim
        self.kv_size = self.num_local_kv_heads * self.head_dim

        self.attn = Attention(
            num_heads=self.num_local_heads,
            head_size=self.head_dim,
            softmax_scale=self.head_dim**-0.5,
            causal=False,
            num_kv_heads=self.num_local_kv_heads,
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor | None,
        rotary_emb: RotaryEmbedding | None,
    ) -> torch.Tensor:
        dtype = hidden_states.dtype

        qkv, _ = self.to_qkv(hidden_states)
        query, key, value = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)

        query = query.unflatten(-1, (self.num_local_heads, self.head_dim))
        key = key.unflatten(-1, (self.num_local_kv_heads, self.head_dim))
        value = value.unflatten(-1, (self.num_local_kv_heads, self.head_dim))

        query, key = _qk_norm_rope(query, key, self.norm_q, self.norm_k, rotary_emb, dtype)

        attn_metadata = AttentionMetadata(attn_mask=attention_mask) if attention_mask is not None else None
        attn_output = self.attn(query, key, value, attn_metadata)
        attn_output = attn_output.flatten(2, 3).type_as(hidden_states)

        attn_output, _ = self.to_out(attn_output)
        return attn_output


class BooguImageJointAttention(nn.Module):
    """Joint instruction+image attention for the double-stream blocks.

    The upstream implementation keeps the per-stream Q/K/V and output
    projections on the attention *processor*
    (`BooguImageDoubleStreamSelfAttnProcessor*`); here they are promoted onto
    this module. The final joint output projection corresponds to the upstream
    `img_instruct_attn.to_out[0]`.
    """

    def __init__(
        self,
        dim: int,
        num_attention_heads: int,
        num_kv_heads: int,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.head_dim = dim // num_attention_heads

        self.img_to_qkv = QKVParallelLinear(
            hidden_size=dim,
            head_size=self.head_dim,
            total_num_heads=num_attention_heads,
            total_num_kv_heads=num_kv_heads,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "img_to_qkv"),
        )
        self.instruct_to_qkv = QKVParallelLinear(
            hidden_size=dim,
            head_size=self.head_dim,
            total_num_heads=num_attention_heads,
            total_num_kv_heads=num_kv_heads,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "instruct_to_qkv"),
        )

        self.norm_q = RMSNorm(self.head_dim, eps=1e-5)
        self.norm_k = RMSNorm(self.head_dim, eps=1e-5)

        # Per-stream output projections (attention output is head-sharded
        # under TP, hence row-parallel).
        self.instruct_out = RowParallelLinear(
            dim,
            dim,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "instruct_out"),
        )
        self.img_out = RowParallelLinear(
            dim,
            dim,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "img_out"),
        )
        # Final joint projection applied to the merged full-dim sequence.
        self.to_out = ReplicatedLinear(
            dim,
            dim,
            bias=False,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "to_out"),
        )

        self.num_local_heads = self.img_to_qkv.num_heads
        self.num_local_kv_heads = self.img_to_qkv.num_kv_heads
        self.q_size = self.num_local_heads * self.head_dim
        self.kv_size = self.num_local_kv_heads * self.head_dim

        self.attn = Attention(
            num_heads=self.num_local_heads,
            head_size=self.head_dim,
            softmax_scale=self.head_dim**-0.5,
            causal=False,
            num_kv_heads=self.num_local_kv_heads,
        )

    def forward(
        self,
        img_hidden_states: torch.Tensor,
        instruct_hidden_states: torch.Tensor,
        joint_attention_mask: torch.Tensor | None,
        rotary_emb: RotaryEmbedding | None,
        encoder_seq_lengths: list[int],
        seq_lengths: list[int],
    ) -> torch.Tensor:
        dtype = img_hidden_states.dtype
        batch_size = img_hidden_states.shape[0]

        img_qkv, _ = self.img_to_qkv(img_hidden_states)
        img_query, img_key, img_value = img_qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)

        instruct_qkv, _ = self.instruct_to_qkv(instruct_hidden_states)
        instruct_query, instruct_key, instruct_value = instruct_qkv.split(
            [self.q_size, self.kv_size, self.kv_size], dim=-1
        )

        query, key, value = _concat_instruction_image_features(
            [img_query, img_key, img_value],
            [instruct_query, instruct_key, instruct_value],
            encoder_seq_lengths,
            seq_lengths,
        )

        query = query.view(batch_size, -1, self.num_local_heads, self.head_dim)
        key = key.view(batch_size, -1, self.num_local_kv_heads, self.head_dim)
        value = value.view(batch_size, -1, self.num_local_kv_heads, self.head_dim)

        query, key = _qk_norm_rope(query, key, self.norm_q, self.norm_k, rotary_emb, dtype)

        attn_metadata = AttentionMetadata(attn_mask=joint_attention_mask) if joint_attention_mask is not None else None
        attn_output = self.attn(query, key, value, attn_metadata)
        attn_output = attn_output.flatten(2, 3).to(dtype)

        instruct_attn_out, img_attn_out = _split_instruction_image_features(
            attn_output,
            encoder_seq_lengths,
            seq_lengths,
            instruct_capacity=instruct_hidden_states.shape[1],
            img_capacity=img_hidden_states.shape[1],
        )
        instruct_projected, _ = self.instruct_out(instruct_attn_out)
        img_projected, _ = self.img_out(img_attn_out)

        merged = _concat_instruction_image_features(
            [img_projected], [instruct_projected], encoder_seq_lengths, seq_lengths
        )[0]
        merged, _ = self.to_out(merged)
        return merged


class BooguImageTransformerBlock(nn.Module):
    """Single-stream block: GQA attention + SwiGLU FFN with optional AdaRMS modulation."""

    def __init__(
        self,
        dim: int,
        num_attention_heads: int,
        num_kv_heads: int,
        multiple_of: int,
        ffn_dim_multiplier: float | None,
        norm_eps: float,
        modulation: bool = True,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.head_dim = dim // num_attention_heads
        self.modulation = modulation

        self.attn = BooguImageSelfAttention(
            dim,
            num_attention_heads,
            num_kv_heads,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "attn"),
        )
        self.feed_forward = LuminaFeedForward(
            dim=dim,
            inner_dim=4 * dim,
            multiple_of=multiple_of,
            ffn_dim_multiplier=ffn_dim_multiplier,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "feed_forward"),
        )

        if modulation:
            self.norm1 = LuminaRMSNormZero(
                embedding_dim=dim,
                norm_eps=norm_eps,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "norm1"),
            )
        else:
            self.norm1 = RMSNorm(dim, eps=norm_eps)

        self.ffn_norm1 = RMSNorm(dim, eps=norm_eps)
        self.norm2 = RMSNorm(dim, eps=norm_eps)
        self.ffn_norm2 = RMSNorm(dim, eps=norm_eps)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor | None,
        image_rotary_emb: RotaryEmbedding | None,
        temb: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if self.modulation:
            if temb is None:
                raise ValueError("temb must be provided when modulation is enabled")
            norm_hidden_states, gate_msa, scale_mlp, gate_mlp = self.norm1(hidden_states, temb)
            attn_output = self.attn(norm_hidden_states, attention_mask, image_rotary_emb)
            hidden_states = hidden_states + gate_msa.unsqueeze(1).tanh() * self.norm2(attn_output)
            mlp_output = self.feed_forward(self.ffn_norm1(hidden_states) * (1 + scale_mlp.unsqueeze(1)))
            hidden_states = hidden_states + gate_mlp.unsqueeze(1).tanh() * self.ffn_norm2(mlp_output)
        else:
            norm_hidden_states = self.norm1(hidden_states)
            attn_output = self.attn(norm_hidden_states, attention_mask, image_rotary_emb)
            hidden_states = hidden_states + self.norm2(attn_output)
            mlp_output = self.feed_forward(self.ffn_norm1(hidden_states))
            hidden_states = hidden_states + self.ffn_norm2(mlp_output)

        return hidden_states


class BooguImageNoiseRefinerTransformerBlock(BooguImageTransformerBlock):
    pass


class BooguImageRefImgRefinerTransformerBlock(BooguImageTransformerBlock):
    pass


class BooguImageContextRefinerTransformerBlock(BooguImageTransformerBlock):
    pass


class BooguImageSingleStreamTransformerBlock(BooguImageTransformerBlock):
    pass


class BooguImageDoubleStreamTransformerBlock(nn.Module):
    """Double-stream block: instruction and image tokens are processed in
    parallel streams coupled by a joint attention, plus an extra image
    self-attention."""

    def __init__(
        self,
        dim: int,
        num_attention_heads: int,
        num_kv_heads: int,
        multiple_of: int,
        ffn_dim_multiplier: float | None,
        norm_eps: float,
        modulation: bool = True,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.head_dim = dim // num_attention_heads
        self.num_attention_heads = num_attention_heads
        self.modulation = modulation
        self.hidden_size = dim

        self.img_instruct_attn = BooguImageJointAttention(
            dim,
            num_attention_heads,
            num_kv_heads,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "img_instruct_attn"),
        )
        self.img_self_attn = BooguImageSelfAttention(
            dim,
            num_attention_heads,
            num_kv_heads,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "img_self_attn"),
        )

        self.img_feed_forward = LuminaFeedForward(
            dim=dim,
            inner_dim=4 * dim,
            multiple_of=multiple_of,
            ffn_dim_multiplier=ffn_dim_multiplier,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "img_feed_forward"),
        )

        if modulation:
            # Image modulation terms: cross-attn, MLP, self-attn.
            self.img_norm1 = LuminaRMSNormZero(
                embedding_dim=dim,
                norm_eps=norm_eps,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "img_norm1"),
            )
            self.img_norm2 = LuminaRMSNormZero(
                embedding_dim=dim,
                norm_eps=norm_eps,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "img_norm2"),
            )
            self.img_norm3 = LuminaRMSNormZero(
                embedding_dim=dim,
                norm_eps=norm_eps,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "img_norm3"),
            )
        else:
            self.img_norm1 = RMSNorm(dim, eps=norm_eps)
            self.img_norm2 = RMSNorm(dim, eps=norm_eps)
            self.img_norm3 = RMSNorm(dim, eps=norm_eps)

        self.img_ffn_norm1 = RMSNorm(dim, eps=norm_eps)
        self.img_attn_norm = RMSNorm(dim, eps=norm_eps)
        self.img_self_attn_norm = RMSNorm(dim, eps=norm_eps)
        self.img_ffn_norm2 = RMSNorm(dim, eps=norm_eps)

        self.instruct_feed_forward = LuminaFeedForward(
            dim=dim,
            inner_dim=4 * dim,
            multiple_of=multiple_of,
            ffn_dim_multiplier=ffn_dim_multiplier,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "instruct_feed_forward"),
        )

        if modulation:
            # Instruction modulation terms: cross-attn, MLP.
            self.instruct_norm1 = LuminaRMSNormZero(
                embedding_dim=dim,
                norm_eps=norm_eps,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "instruct_norm1"),
            )
            self.instruct_norm2 = LuminaRMSNormZero(
                embedding_dim=dim,
                norm_eps=norm_eps,
                quant_config=quant_config,
                prefix=_join_prefix(prefix, "instruct_norm2"),
            )
        else:
            self.instruct_norm1 = RMSNorm(dim, eps=norm_eps)
            self.instruct_norm2 = RMSNorm(dim, eps=norm_eps)

        self.instruct_ffn_norm1 = RMSNorm(dim, eps=norm_eps)
        self.instruct_attn_norm = RMSNorm(dim, eps=norm_eps)
        self.instruct_ffn_norm2 = RMSNorm(dim, eps=norm_eps)

    def forward(
        self,
        img_hidden_states: torch.Tensor,  # [B, L_img, D] (ref_img + noise_img)
        instruct_hidden_states: torch.Tensor,  # [B, L_instruct, D]
        img_attention_mask: torch.Tensor | None,  # [B, L_img]
        joint_attention_mask: torch.Tensor | None,  # [B, L_total]
        image_rotary_emb: RotaryEmbedding | None,  # Each tensor is [B, L_img, head_dim].
        rotary_emb: RotaryEmbedding | None,  # Each tensor is [B, L_total, head_dim].
        temb: torch.Tensor | None = None,
        encoder_seq_lengths: list[int] | None = None,
        seq_lengths: list[int] | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if self.modulation and temb is None:
            raise ValueError("temb must be provided when modulation is enabled")

        batch_size = img_hidden_states.shape[0]
        L_instruct = instruct_hidden_states.shape[1]
        L_img = img_hidden_states.shape[1]

        if self.modulation:
            img_norm1_out, img_gate_msa, img_scale_mlp, img_gate_mlp = self.img_norm1(img_hidden_states, temb)
            img_norm2_out, img_shift_mlp, _, _ = self.img_norm2(img_hidden_states, temb)
            img_norm3_out, img_gate_self, _, _ = self.img_norm3(img_hidden_states, temb)

            (
                instruct_norm1_out,
                instruct_gate_msa,
                instruct_scale_mlp,
                instruct_gate_mlp,
            ) = self.instruct_norm1(instruct_hidden_states, temb)
            instruct_norm2_out, instruct_shift_mlp, _, _ = self.instruct_norm2(instruct_hidden_states, temb)

            joint_attn_out = self.img_instruct_attn(
                img_norm1_out,
                instruct_norm1_out,
                joint_attention_mask,
                rotary_emb,
                encoder_seq_lengths,
                seq_lengths,
            )

            # Split the joint output back into instruction/image segments.
            instruct_attn_out = instruct_hidden_states.new_zeros(batch_size, L_instruct, self.hidden_size)
            img_attn_out = img_hidden_states.new_zeros(batch_size, L_img, self.hidden_size)
            for i, (encoder_seq_len, seq_len) in enumerate(zip(encoder_seq_lengths, seq_lengths)):
                instruct_attn_out[i, :encoder_seq_len] = joint_attn_out[i, :encoder_seq_len]
                img_attn_out[i, : seq_len - encoder_seq_len] = joint_attn_out[i, encoder_seq_len:seq_len]

            img_self_attn_out = self.img_self_attn(img_norm3_out, img_attention_mask, image_rotary_emb)

            img_hidden_states = img_hidden_states + img_gate_msa.unsqueeze(1).tanh() * self.img_attn_norm(img_attn_out)
            img_hidden_states = img_hidden_states + img_gate_self.unsqueeze(1).tanh() * self.img_self_attn_norm(
                img_self_attn_out
            )

            img_mlp_input = (1 + img_scale_mlp.unsqueeze(1)) * img_norm2_out + img_shift_mlp.unsqueeze(1)
            img_mlp_out = self.img_feed_forward(self.img_ffn_norm1(img_mlp_input))
            img_hidden_states = img_hidden_states + img_gate_mlp.unsqueeze(1).tanh() * self.img_ffn_norm2(img_mlp_out)

            instruct_hidden_states = instruct_hidden_states + instruct_gate_msa.unsqueeze(
                1
            ).tanh() * self.instruct_attn_norm(instruct_attn_out)

            instruct_mlp_input = (
                1 + instruct_scale_mlp.unsqueeze(1)
            ) * instruct_norm2_out + instruct_shift_mlp.unsqueeze(1)
            instruct_mlp_out = self.instruct_feed_forward(self.instruct_ffn_norm1(instruct_mlp_input))
            instruct_hidden_states = instruct_hidden_states + instruct_gate_mlp.unsqueeze(
                1
            ).tanh() * self.instruct_ffn_norm2(instruct_mlp_out)

        else:
            img_norm1_out = self.img_norm1(img_hidden_states)
            img_norm3_out = self.img_norm3(img_hidden_states)
            instruct_norm1_out = self.instruct_norm1(instruct_hidden_states)

            joint_attn_out = self.img_instruct_attn(
                img_norm1_out,
                instruct_norm1_out,
                joint_attention_mask,
                rotary_emb,
                encoder_seq_lengths,
                seq_lengths,
            )

            instruct_attn_out = instruct_hidden_states.new_zeros(batch_size, L_instruct, self.hidden_size)
            img_attn_out = img_hidden_states.new_zeros(batch_size, L_img, self.hidden_size)
            for i, (encoder_seq_len, seq_len) in enumerate(zip(encoder_seq_lengths, seq_lengths)):
                instruct_attn_out[i, :encoder_seq_len] = joint_attn_out[i, :encoder_seq_len]
                img_attn_out[i, : seq_len - encoder_seq_len] = joint_attn_out[i, encoder_seq_len:seq_len]

            img_self_attn_out = self.img_self_attn(img_norm3_out, img_attention_mask, image_rotary_emb)

            img_hidden_states = img_hidden_states + self.img_attn_norm(img_attn_out)
            img_hidden_states = img_hidden_states + self.img_self_attn_norm(img_self_attn_out)
            img_norm2_out = self.img_norm2(img_hidden_states)
            img_mlp_out = self.img_feed_forward(self.img_ffn_norm1(img_norm2_out))
            img_hidden_states = img_hidden_states + self.img_ffn_norm2(img_mlp_out)

            instruct_hidden_states = instruct_hidden_states + self.instruct_attn_norm(instruct_attn_out)
            instruct_norm2_out = self.instruct_norm2(instruct_hidden_states)
            instruct_mlp_out = self.instruct_feed_forward(self.instruct_ffn_norm1(instruct_norm2_out))
            instruct_hidden_states = instruct_hidden_states + self.instruct_ffn_norm2(instruct_mlp_out)

        return img_hidden_states, instruct_hidden_states


def _cal_preprocessed_instruction_feat_dim(instruction_feature_configs: dict) -> int:
    num_instruction_feature_layers = max(instruction_feature_configs.get("num_instruction_feature_layers", 1), 1)
    instruction_feat_dim = instruction_feature_configs.get("instruction_feat_dim", 4096)
    reduce_type = instruction_feature_configs.get("reduce_type", "concat")
    if "cat" in reduce_type.lower():
        return num_instruction_feature_layers * instruction_feat_dim
    elif "mean" in reduce_type.lower():
        return instruction_feat_dim
    else:
        raise ValueError(f"Invalid reduce_type: {reduce_type}")


# Packed (fused) projections vs. the logical sub-projections the diffusers
# checkpoint stores, in the ``(param_name, shard_name, shard_id)`` form used
# across vllm-omni. ``load_weights`` consumes it directly, and loader consumers
# that discover it via ``stacked_params_mapping`` (LoRA, quantized loaders) get
# the packed -> sub-layer relationship for free.
#
# The QKV entries stay leaf-scoped: each fused source (``to_q`` on the
# self-attention module, ``img_to_q`` / ``instruct_to_q`` on the joint
# attention) has a distinct leaf, and ``.to_q.`` cannot collide with
# ``.img_to_q.`` because the preceding character is ``_`` rather than ``.``.
# The FFN entries are path-qualified instead: ``linear_1`` also names the
# timestep embedder and the ``norm_out`` projections, which must load 1:1 and
# are not fused.
_BOOGU_STACKED_PARAMS_MAPPING = (
    # self-attention: noise / reference-image / context refiners, the
    # single-stream blocks, and the double-stream image self-attention.
    (".to_qkv.", ".to_q.", "q"),
    (".to_qkv.", ".to_k.", "k"),
    (".to_qkv.", ".to_v.", "v"),
    # joint (instruction + image) attention of the double-stream blocks.
    (".img_to_qkv.", ".img_to_q.", "q"),
    (".img_to_qkv.", ".img_to_k.", "k"),
    (".img_to_qkv.", ".img_to_v.", "v"),
    (".instruct_to_qkv.", ".instruct_to_q.", "q"),
    (".instruct_to_qkv.", ".instruct_to_k.", "k"),
    (".instruct_to_qkv.", ".instruct_to_v.", "v"),
    # feed-forward gate/up: ``linear_1`` is the gate (shard 0) and
    # ``linear_3`` the input (shard 1), matching the packed order the SwiGLU
    # activation consumes.
    (".feed_forward.gate_up_proj.", ".feed_forward.linear_1.", 0),
    (".feed_forward.gate_up_proj.", ".feed_forward.linear_3.", 1),
    (".img_feed_forward.gate_up_proj.", ".img_feed_forward.linear_1.", 0),
    (".img_feed_forward.gate_up_proj.", ".img_feed_forward.linear_3.", 1),
    (".instruct_feed_forward.gate_up_proj.", ".instruct_feed_forward.linear_1.", 0),
    (".instruct_feed_forward.gate_up_proj.", ".instruct_feed_forward.linear_3.", 1),
)


class _BooguImageSPBoundary(nn.Module):
    """Identity module used by framework SP split hooks."""

    def forward(self, *tensors: torch.Tensor) -> tuple[torch.Tensor, ...]:
        return tensors


class _BooguImageSPGather(nn.Module):
    """Identity module used by the framework SP gather hook."""

    def forward(self, tensor: torch.Tensor) -> torch.Tensor:
        return tensor


class BooguImageTransformer2DModel(nn.Module):
    """Boogu-Image transformer with mixed stream topology.

    Early layers use double-stream (dual-stream) processing, then switch to
    single-stream joint processing. Context/noise/reference-image refiner
    blocks run before the main stack.
    """

    # Noise refiner, reference image refiner, and double stream layers are
    # kept out of regional torch.compile for numerical stability (matches the
    # upstream `_repeated_blocks`).
    _repeated_blocks = [
        "BooguImageTransformerBlock",
        "BooguImageContextRefinerTransformerBlock",
        "BooguImageSingleStreamTransformerBlock",
    ]
    _layerwise_offload_blocks_attrs = ["single_stream_layers", "double_stream_layers"]
    # Boundary outputs are hidden states, masks, and RoPE; each triplet is in
    # image/reference/context order so tensors sharing a sequence reuse metadata.
    # Twelve entries: 3 hidden states (dim=3), 3 masks (dim=2), then the
    # rotary cos/sin pairs for image/reference/context (dim=3 each). Real-valued
    # RoPE returns tuples, so each rotary embedding contributes two tensors.
    _sp_plan = {
        "sp_shard_boundary": {
            index: SequenceParallelInput(
                split_dim=1,
                expected_dims=dims,
                split_output=True,
                auto_pad=True,
                shard_group=shard_group,
            )
            for index, (dims, shard_group) in enumerate(
                zip(
                    (3, 3, 3, 2, 2, 2, 3, 3, 3, 3, 3, 3),
                    (
                        "image",
                        "reference",
                        "context",
                        "image",
                        "reference",
                        "context",
                        "image",
                        "image",
                        "reference",
                        "reference",
                        "context",
                        "context",
                    ),
                )
            )
        },
        "sp_gather_boundary": SequenceParallelOutput(
            gather_dim=1,
            expected_dims=3,
            shard_group="image",
        ),
    }

    def __init__(
        self,
        od_config: OmniDiffusionConfig,
        quant_config: "QuantizationConfig | None" = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        # Published here rather than in ``load_weights`` so loader consumers
        # that only inspect the module tree (LoRA discovery, quantized weight
        # loaders) always see the packed -> sub-layer relationship.
        self.stacked_params_mapping = list(_BOOGU_STACKED_PARAMS_MAPPING)
        self.od_config = od_config
        cfg = od_config.tf_model_config

        patch_size = cfg.get("patch_size", 2)
        in_channels = cfg.get("in_channels", 16)
        out_channels = cfg.get("out_channels", None)
        hidden_size = cfg.get("hidden_size", 2304)
        num_layers = cfg.get("num_layers", 26)
        num_double_stream_layers = cfg.get("num_double_stream_layers", 2)
        num_refiner_layers = cfg.get("num_refiner_layers", 2)
        num_attention_heads = cfg.get("num_attention_heads", 24)
        num_kv_heads = cfg.get("num_kv_heads", 8)
        multiple_of = cfg.get("multiple_of", 256)
        ffn_dim_multiplier = cfg.get("ffn_dim_multiplier", None)
        norm_eps = cfg.get("norm_eps", 1e-5)
        axes_dim_rope = tuple(cfg.get("axes_dim_rope", (40, 40, 40)))
        axes_lens = tuple(cfg.get("axes_lens", (2048, 1664, 1664)))
        instruction_feature_configs = cfg.get(
            "instruction_feature_configs",
            {"instruction_feat_dim": 1024, "reduce_type": "mean", "num_instruction_feature_layers": 1},
        )
        prompt_tuning_configs = cfg.get("prompt_tuning_configs", {"use_prompt_tuning": False})
        timestep_scale = cfg.get("timestep_scale", 1.0)

        if (hidden_size // num_attention_heads) != sum(axes_dim_rope):
            raise ValueError(
                f"hidden_size // num_attention_heads ({hidden_size // num_attention_heads}) "
                f"must equal sum(axes_dim_rope) ({sum(axes_dim_rope)})"
            )
        if num_double_stream_layers > num_layers:
            raise ValueError(
                f"num_double_stream_layers ({num_double_stream_layers}) cannot be greater than "
                f"num_layers ({num_layers})"
            )
        if prompt_tuning_configs.get("use_prompt_tuning", False):
            raise NotImplementedError(
                "Prompt tuning is a training-time feature and is not supported by the "
                "native vLLM-Omni BooguImageTransformer2DModel."
            )

        self.patch_size = patch_size
        self.in_channels = in_channels
        self.out_channels = out_channels or in_channels
        self.hidden_size = hidden_size
        self.num_attention_heads = num_attention_heads
        self.num_double_stream_layers = num_double_stream_layers
        self.num_single_stream_layers = num_layers - num_double_stream_layers
        self.axes_dim_rope = axes_dim_rope
        self.axes_lens = axes_lens
        self.instruction_feature_configs = instruction_feature_configs
        self.preprocessed_instruction_feat_dim = _cal_preprocessed_instruction_feat_dim(instruction_feature_configs)

        self.rope_embedder = BooguImageDoubleStreamRotaryPosEmbed(
            theta=10000,
            axes_dim=axes_dim_rope,
            axes_lens=axes_lens,
            patch_size=patch_size,
        )
        self.sp_shard_boundary = _BooguImageSPBoundary()
        self.sp_gather_boundary = _BooguImageSPGather()

        self.x_embedder = nn.Linear(
            in_features=patch_size * patch_size * in_channels,
            out_features=hidden_size,
        )
        self.ref_image_patch_embedder = nn.Linear(
            in_features=patch_size * patch_size * in_channels,
            out_features=hidden_size,
        )

        self.time_caption_embed = Lumina2CombinedTimestepCaptionEmbedding(
            hidden_size=hidden_size,
            instruction_feat_dim=self.preprocessed_instruction_feat_dim,
            norm_eps=norm_eps,
            timestep_scale=timestep_scale,
        )

        self.noise_refiner = nn.ModuleList(
            [
                BooguImageNoiseRefinerTransformerBlock(
                    hidden_size,
                    num_attention_heads,
                    num_kv_heads,
                    multiple_of,
                    ffn_dim_multiplier,
                    norm_eps,
                    modulation=True,
                    quant_config=quant_config,
                    prefix=_join_prefix(prefix, f"noise_refiner.{i}"),
                )
                for i in range(num_refiner_layers)
            ]
        )

        self.ref_image_refiner = nn.ModuleList(
            [
                BooguImageRefImgRefinerTransformerBlock(
                    hidden_size,
                    num_attention_heads,
                    num_kv_heads,
                    multiple_of,
                    ffn_dim_multiplier,
                    norm_eps,
                    modulation=True,
                    quant_config=quant_config,
                    prefix=_join_prefix(prefix, f"ref_image_refiner.{i}"),
                )
                for i in range(num_refiner_layers)
            ]
        )

        self.context_refiner = nn.ModuleList(
            [
                BooguImageContextRefinerTransformerBlock(
                    hidden_size,
                    num_attention_heads,
                    num_kv_heads,
                    multiple_of,
                    ffn_dim_multiplier,
                    norm_eps,
                    modulation=False,
                    quant_config=quant_config,
                    prefix=_join_prefix(prefix, f"context_refiner.{i}"),
                )
                for i in range(num_refiner_layers)
            ]
        )

        # Mixed architecture: dual-stream first, then single-stream.
        self.double_stream_layers = nn.ModuleList(
            [
                BooguImageDoubleStreamTransformerBlock(
                    hidden_size,
                    num_attention_heads,
                    num_kv_heads,
                    multiple_of,
                    ffn_dim_multiplier,
                    norm_eps,
                    modulation=True,
                    quant_config=quant_config,
                    prefix=_join_prefix(prefix, f"double_stream_layers.{i}"),
                )
                for i in range(num_double_stream_layers)
            ]
        )

        self.single_stream_layers = nn.ModuleList(
            [
                BooguImageSingleStreamTransformerBlock(
                    hidden_size,
                    num_attention_heads,
                    num_kv_heads,
                    multiple_of,
                    ffn_dim_multiplier,
                    norm_eps,
                    modulation=True,
                    quant_config=quant_config,
                    prefix=_join_prefix(prefix, f"single_stream_layers.{i}"),
                )
                for i in range(self.num_single_stream_layers)
            ]
        )

        self.norm_out = LuminaLayerNormContinuous(
            embedding_dim=hidden_size,
            conditioning_embedding_dim=min(hidden_size, 1024),
            elementwise_affine=False,
            eps=1e-6,
            bias=True,
            out_dim=patch_size * patch_size * self.out_channels,
            quant_config=quant_config,
            prefix=_join_prefix(prefix, "norm_out"),
        )

        # Distinguish multiple reference images (max 5).
        self.image_index_embedding = nn.Parameter(torch.randn(5, hidden_size))

    def preprocess_instruction_hidden_states(self, raw_instruction_hidden_states):
        """Reduce the raw MLLM hidden states to the transformer feature dim.

        Mirrors upstream ``preprocess_instruction_hidden_states``: a single
        tensor passes through unchanged; a list of per-layer states is combined
        by ``concat`` or ``mean`` according to ``instruction_feature_configs``.
        """
        cfg = self.instruction_feature_configs
        num_instruction_feature_layers = max(cfg.get("num_instruction_feature_layers", 1), 1)
        reduce_type = cfg.get("reduce_type", "concat")

        if isinstance(raw_instruction_hidden_states, torch.Tensor):
            instruction_hidden_states = raw_instruction_hidden_states
        elif isinstance(raw_instruction_hidden_states, (list, tuple)):
            assert len(raw_instruction_hidden_states) == num_instruction_feature_layers
            if "cat" in reduce_type.lower():
                instruction_hidden_states = torch.cat(raw_instruction_hidden_states, dim=-1)
            elif "mean" in reduce_type.lower():
                instruction_hidden_states = torch.mean(torch.stack(raw_instruction_hidden_states), dim=0)
            else:
                raise ValueError(f"Invalid reduce_type: {reduce_type}")
        else:
            raise ValueError(
                "Invalid type of raw_instruction_hidden_states, expected torch.Tensor or list, "
                f"but got {type(raw_instruction_hidden_states)}"
            )

        assert self.preprocessed_instruction_feat_dim == instruction_hidden_states.shape[-1]
        return instruction_hidden_states

    def flat_and_pad_to_seq(self, hidden_states, ref_image_hidden_states):
        """Flatten patch tokens and pad to batched sequences.

        Ported from upstream; for text-to-image ``ref_image_hidden_states`` is
        ``None`` and the reference-image branch collapses to zero-length.
        """
        batch_size = len(hidden_states)
        p = self.patch_size
        device = hidden_states[0].device

        img_sizes = [(img.size(1), img.size(2)) for img in hidden_states]
        l_effective_img_len = [(H // p) * (W // p) for (H, W) in img_sizes]

        if ref_image_hidden_states is not None:
            ref_img_sizes = [
                [(img.size(1), img.size(2)) for img in imgs] if imgs is not None else None
                for imgs in ref_image_hidden_states
            ]
            l_effective_ref_img_len = [
                [(ref_img_size[0] // p) * (ref_img_size[1] // p) for ref_img_size in _ref_img_sizes]
                if _ref_img_sizes is not None
                else [0]
                for _ref_img_sizes in ref_img_sizes
            ]
        else:
            ref_img_sizes = [None for _ in range(batch_size)]
            l_effective_ref_img_len = [[0] for _ in range(batch_size)]

        max_ref_img_len = max(sum(ref_img_len) for ref_img_len in l_effective_ref_img_len)
        max_img_len = max(l_effective_img_len)

        # Reference-image patch embeddings.
        flat_ref_img_hidden_states = []
        for i in range(batch_size):
            if ref_img_sizes[i] is not None:
                imgs = []
                for ref_img in ref_image_hidden_states[i]:
                    C, H, W = ref_img.size()
                    ref_img = rearrange(ref_img, "c (h p1) (w p2) -> (h w) (p1 p2 c)", p1=p, p2=p)
                    imgs.append(ref_img)
                flat_ref_img_hidden_states.append(torch.cat(imgs, dim=0))
            else:
                flat_ref_img_hidden_states.append(None)

        # Noise-image patch embeddings.
        flat_hidden_states = []
        for i in range(batch_size):
            img = hidden_states[i]
            C, H, W = img.size()
            img = rearrange(img, "c (h p1) (w p2) -> (h w) (p1 p2 c)", p1=p, p2=p)
            flat_hidden_states.append(img)

        padded_ref_img_hidden_states = torch.zeros(
            batch_size,
            max_ref_img_len,
            flat_hidden_states[0].shape[-1],
            device=device,
            dtype=flat_hidden_states[0].dtype,
        )
        padded_ref_img_mask = torch.zeros(batch_size, max_ref_img_len, dtype=torch.bool, device=device)
        for i in range(batch_size):
            if ref_img_sizes[i] is not None:
                padded_ref_img_hidden_states[i, : sum(l_effective_ref_img_len[i])] = flat_ref_img_hidden_states[i]
                padded_ref_img_mask[i, : sum(l_effective_ref_img_len[i])] = True

        padded_hidden_states = torch.zeros(
            batch_size,
            max_img_len,
            flat_hidden_states[0].shape[-1],
            device=device,
            dtype=flat_hidden_states[0].dtype,
        )
        padded_img_mask = torch.zeros(batch_size, max_img_len, dtype=torch.bool, device=device)
        for i in range(batch_size):
            padded_hidden_states[i, : l_effective_img_len[i]] = flat_hidden_states[i]
            padded_img_mask[i, : l_effective_img_len[i]] = True

        return (
            padded_hidden_states,
            padded_ref_img_hidden_states,
            padded_img_mask,
            padded_ref_img_mask,
            l_effective_ref_img_len,
            l_effective_img_len,
            ref_img_sizes,
            img_sizes,
        )

    def img_patch_embed_and_refine(
        self,
        hidden_states: torch.Tensor,
        ref_image_hidden_states: torch.Tensor,
        padded_img_mask: torch.Tensor,
        padded_ref_img_mask: torch.Tensor,
        noise_rotary_emb: RotaryEmbedding,
        ref_img_rotary_emb: RotaryEmbedding,
        l_effective_ref_img_len: list[list[int]],
        l_effective_img_len: list[int],
        temb: torch.Tensor,
        per_rank_ref_lengths: list[list[list[int]]] | None = None,
    ):
        """Embed image patches and run the refiner blocks.

        The reference-image refiner is skipped when there are no reference-image
        tokens (text-to-image), which is numerically identical to upstream (the
        combined sequence only reads ``[:sum(ref_img_len)]`` = empty) while
        avoiding a degenerate zero-length attention.
        """
        batch_size = len(hidden_states)
        max_combined_img_len = hidden_states.shape[1] + ref_image_hidden_states.shape[1]

        hidden_states = self.x_embedder(hidden_states)
        ref_image_hidden_states = self.ref_image_patch_embedder(ref_image_hidden_states)

        for i in range(batch_size):
            shift = 0
            for j, ref_img_len in enumerate(l_effective_ref_img_len[i]):
                ref_image_hidden_states[i, shift : shift + ref_img_len, :] = (
                    ref_image_hidden_states[i, shift : shift + ref_img_len, :] + self.image_index_embedding[j]
                )
                shift += ref_img_len

        for layer in self.noise_refiner:
            hidden_states = layer(hidden_states, padded_img_mask, noise_rotary_emb, temb)

        flat_l_effective_ref_img_len = list(itertools.chain(*l_effective_ref_img_len))
        num_ref_images = len(flat_l_effective_ref_img_len)
        max_ref_img_len = max(flat_l_effective_ref_img_len)
        sp_sharded = per_rank_ref_lengths is not None and len(per_rank_ref_lengths) > 1
        if sp_sharded:
            # Keep the packed reference batch at the padded local capacity so
            # every SP rank retains the equal-length contract.
            max_ref_img_len = max(
                max_ref_img_len,
                padded_ref_img_mask.shape[1],
            )

        if max_ref_img_len > 0:
            batch_ref_img_mask = ref_image_hidden_states.new_zeros(num_ref_images, max_ref_img_len, dtype=torch.bool)
            batch_ref_image_hidden_states = ref_image_hidden_states.new_zeros(
                num_ref_images, max_ref_img_len, self.hidden_size
            )
            batch_ref_img_rotary_emb: RotaryEmbedding = (
                hidden_states.new_zeros(
                    num_ref_images,
                    max_ref_img_len,
                    ref_img_rotary_emb[0].shape[-1],
                    dtype=ref_img_rotary_emb[0].dtype,
                ),
                hidden_states.new_zeros(
                    num_ref_images,
                    max_ref_img_len,
                    ref_img_rotary_emb[1].shape[-1],
                    dtype=ref_img_rotary_emb[1].dtype,
                ),
            )
            batch_temb = temb.new_zeros(num_ref_images, *temb.shape[1:], dtype=temb.dtype)

            # Flatten reference images into a temporary batch.
            idx = 0
            for i in range(batch_size):
                shift = 0
                for ref_img_len in l_effective_ref_img_len[i]:
                    batch_ref_img_mask[idx, :ref_img_len] = True
                    batch_ref_image_hidden_states[idx, :ref_img_len] = ref_image_hidden_states[
                        i, shift : shift + ref_img_len
                    ]
                    for batch_freqs, ref_freqs in zip(batch_ref_img_rotary_emb, ref_img_rotary_emb):
                        batch_freqs[idx, :ref_img_len] = ref_freqs[i, shift : shift + ref_img_len]
                    batch_temb[idx] = temb[i]
                    shift += ref_img_len
                    idx += 1

            if _FUSED_QK_NORM_ROPE:
                # The rebuilt per-reference-image tuple needs its own packed
                # table; the forward-level tuples do not flow into this batch.
                batch_ref_img_rotary_emb = _with_packed_rope_table(batch_ref_img_rotary_emb)

            if sp_sharded:
                # Ulysses will concatenate each rank's packed reference batch,
                # so the mask must cover all ranks' segments.
                ref_attention_mask = rank_concat_mask_or_none(
                    [list(itertools.chain(*rank_lengths)) for rank_lengths in per_rank_ref_lengths],
                    max_ref_img_len,
                    like=batch_ref_img_mask,
                )
            else:
                ref_attention_mask = (
                    batch_ref_img_mask
                    if any(length != max_ref_img_len for length in flat_l_effective_ref_img_len)
                    else None
                )

            for layer in self.ref_image_refiner:
                batch_ref_image_hidden_states = layer(
                    batch_ref_image_hidden_states,
                    ref_attention_mask,
                    batch_ref_img_rotary_emb,
                    batch_temb,
                )

            # Restore reference-image sequence layout.
            idx = 0
            for i in range(batch_size):
                shift = 0
                for ref_img_len in l_effective_ref_img_len[i]:
                    ref_image_hidden_states[i, shift : shift + ref_img_len] = batch_ref_image_hidden_states[
                        idx, :ref_img_len
                    ]
                    shift += ref_img_len
                    idx += 1

        combined_img_hidden_states = hidden_states.new_zeros(batch_size, max_combined_img_len, self.hidden_size)
        for i, (ref_img_len, img_len) in enumerate(zip(l_effective_ref_img_len, l_effective_img_len)):
            combined_img_hidden_states[i, : sum(ref_img_len)] = ref_image_hidden_states[i, : sum(ref_img_len)]
            combined_img_hidden_states[i, sum(ref_img_len) : sum(ref_img_len) + img_len] = hidden_states[i, :img_len]

        return combined_img_hidden_states

    def forward(
        self,
        hidden_states: torch.Tensor | list[torch.Tensor],
        timestep: torch.Tensor,
        instruction_hidden_states: torch.Tensor,
        freqs_real: RotaryFrequencyTables,
        instruction_attention_mask: torch.Tensor,
        ref_image_hidden_states: list[list[torch.Tensor]] | None = None,
    ) -> torch.Tensor:
        """Denoise one step: refiner -> double-stream -> fuse -> single-stream -> unpatchify.

        Ported from upstream ``BooguImageTransformer2DModel.forward`` with the
        TeaCache/TaylorSeer/PEFT/gradient-checkpointing branches removed. Returns
        the velocity prediction as a ``[B, C, H_lat, W_lat]`` tensor.
        """
        instruction_hidden_states = self.preprocess_instruction_hidden_states(instruction_hidden_states)

        batch_size = len(hidden_states)
        is_hidden_states_tensor = isinstance(hidden_states, torch.Tensor)
        if is_hidden_states_tensor:
            assert hidden_states.ndim == 4
            hidden_states = [_hidden_states for _hidden_states in hidden_states]

        device = hidden_states[0].device

        # Timestep and instruction embedding.
        temb, instruction_hidden_states = self.time_caption_embed(
            timestep, instruction_hidden_states, hidden_states[0].dtype
        )

        # Flatten and pad token sequences.
        (
            hidden_states,
            ref_image_hidden_states,
            img_mask,
            ref_img_mask,
            l_effective_ref_img_len,
            l_effective_img_len,
            ref_img_sizes,
            img_sizes,
        ) = self.flat_and_pad_to_seq(hidden_states, ref_image_hidden_states)

        # Build rotary embeddings and sequence lengths.
        (
            context_rotary_emb,
            ref_img_rotary_emb,
            noise_rotary_emb,
            _,
            global_encoder_seq_lengths,
            _,
            _,
            _,
        ) = self.rope_embedder(
            freqs_real,
            instruction_attention_mask,
            l_effective_ref_img_len,
            l_effective_img_len,
            ref_img_sizes,
            img_sizes,
            device,
        )

        # RoPE is real-valued (cos, sin) tuples; unpack them to shard cos and
        # sin independently through the split hook, then re-pair below.
        noise_cos, noise_sin = noise_rotary_emb
        ref_cos, ref_sin = ref_img_rotary_emb
        context_cos, context_sin = context_rotary_emb
        (
            hidden_states,
            ref_image_hidden_states,
            instruction_hidden_states,
            img_mask,
            ref_img_mask,
            instruction_attention_mask,
            noise_cos,
            noise_sin,
            ref_cos,
            ref_sin,
            context_cos,
            context_sin,
        ) = self.sp_shard_boundary(
            hidden_states,
            ref_image_hidden_states,
            instruction_hidden_states,
            img_mask,
            ref_img_mask,
            instruction_attention_mask,
            noise_cos,
            noise_sin,
            ref_cos,
            ref_sin,
            context_cos,
            context_sin,
        )
        noise_rotary_emb = (noise_cos, noise_sin)
        ref_img_rotary_emb = (ref_cos, ref_sin)
        context_rotary_emb = (context_cos, context_sin)

        image_layout = ShardLayout.resolve("image", local_seq_len=img_mask.shape[1])
        reference_layout = ShardLayout.resolve("reference", local_seq_len=ref_img_mask.shape[1])
        context_layout = ShardLayout.resolve("context", local_seq_len=instruction_attention_mask.shape[1])
        sp_world_size = image_layout.world_size
        sp_rank = image_layout.rank

        context_mask_required = context_layout.padding_size > 0 or any(
            length != context_layout.original_seq_len for length in global_encoder_seq_lengths
        )
        noise_mask_required = image_layout.padding_size > 0 or any(
            length != image_layout.original_seq_len for length in l_effective_img_len
        )
        ref_mask_required = reference_layout.padding_size > 0 or any(
            sum(lengths) != reference_layout.original_seq_len for lengths in l_effective_ref_img_len
        )

        global_img_lengths = list(l_effective_img_len)
        # Ulysses concatenates the rank-local sequences after its all-to-all, so
        # attention masks must describe that rank-concatenated layout. Every
        # rank's shard bounds are pure arithmetic over the global lengths, so
        # each rank derives all ranks' segments without any communication.
        ranks = range(sp_world_size)
        per_rank_img_lengths = [image_layout.valid_lengths(global_img_lengths, rank=r) for r in ranks]
        per_rank_ref_lengths = [reference_layout.segment_lengths(l_effective_ref_img_len, rank=r) for r in ranks]
        per_rank_encoder_lengths = [context_layout.valid_lengths(global_encoder_seq_lengths, rank=r) for r in ranks]

        local_img_lengths = per_rank_img_lengths[sp_rank]
        local_ref_lengths = per_rank_ref_lengths[sp_rank]
        local_encoder_lengths = per_rank_encoder_lengths[sp_rank]
        (
            rotary_emb,
            combined_img_rotary_emb,
            seq_lengths,
            combined_img_seq_lengths,
        ) = pack_local_rotary(
            context_rotary_emb,
            ref_img_rotary_emb,
            noise_rotary_emb,
            local_encoder_lengths,
            local_ref_lengths,
            local_img_lengths,
        )

        if _FUSED_QK_NORM_ROPE:
            # One packed [cos|sin] table per rotary embedding that reaches an
            # attention, built once per forward; the tuples grow a third
            # element that the fused path consumes and the eager path ignores.
            # Under SP, cos/sin are already the rank-local sharded tensors, so
            # the packed table matches the fused kernel's local Q/K geometry.
            # (ref_img_rotary_emb is packed inside img_patch_embed_and_refine,
            # on the rebuilt per-reference-image batch tuple.)
            context_rotary_emb = _with_packed_rope_table(context_rotary_emb)
            noise_rotary_emb = _with_packed_rope_table(noise_rotary_emb)
            rotary_emb = _with_packed_rope_table(rotary_emb)
            combined_img_rotary_emb = _with_packed_rope_table(combined_img_rotary_emb)

        context_attention_mask = rank_concat_mask_or_none(
            per_rank_encoder_lengths,
            context_layout.local_seq_len,
            like=instruction_attention_mask,
            required=context_mask_required,
        )
        noise_attention_mask = rank_concat_mask_or_none(
            per_rank_img_lengths,
            image_layout.local_seq_len,
            like=img_mask,
            required=noise_mask_required,
        )

        # Context refinement.
        for layer in self.context_refiner:
            instruction_hidden_states = layer(
                instruction_hidden_states,
                context_attention_mask,
                context_rotary_emb,
            )

        # Image patch embedding and refinement.
        combined_img_hidden_states = self.img_patch_embed_and_refine(
            hidden_states,
            ref_image_hidden_states,
            noise_attention_mask,
            ref_img_mask,
            noise_rotary_emb,
            ref_img_rotary_emb,
            local_ref_lengths,
            local_img_lengths,
            temb,
            per_rank_ref_lengths=per_rank_ref_lengths,
        )

        instruct_hidden_states = instruction_hidden_states
        img_hidden_states = combined_img_hidden_states

        # Joint mask for [instruct + image], over the rank-concatenated sequence.
        per_rank_combined_img_lengths = [
            [sum(ref_lengths) + img_length for ref_lengths, img_length in zip(ref_per_sample, img_per_sample)]
            for ref_per_sample, img_per_sample in zip(per_rank_ref_lengths, per_rank_img_lengths)
        ]
        per_rank_seq_lengths = [
            [encoder_length + combined_length for encoder_length, combined_length in zip(enc_per_sample, comb)]
            for enc_per_sample, comb in zip(per_rank_encoder_lengths, per_rank_combined_img_lengths)
        ]
        joint_attention_mask = rank_concat_mask_or_none(
            per_rank_seq_lengths,
            rotary_emb[0].shape[1],
            like=hidden_states,
            required=(context_mask_required or noise_mask_required or ref_mask_required),
        )

        # Dual-stream (double-stream) stage.
        if self.num_double_stream_layers > 0:
            img_attention_mask = rank_concat_mask_or_none(
                per_rank_combined_img_lengths,
                combined_img_rotary_emb[0].shape[1],
                like=hidden_states,
                required=noise_mask_required or ref_mask_required,
            )

            for layer in self.double_stream_layers:
                img_hidden_states, instruct_hidden_states = layer(
                    img_hidden_states,
                    instruct_hidden_states,
                    img_attention_mask,
                    joint_attention_mask,
                    combined_img_rotary_emb,
                    rotary_emb,
                    temb,
                    local_encoder_lengths,
                    seq_lengths,
                )

        # Fuse streams to joint sequence.
        joint_hidden_states = hidden_states.new_zeros(
            batch_size,
            rotary_emb[0].shape[1],
            self.hidden_size,
        )
        for i, (encoder_seq_len, seq_len) in enumerate(zip(local_encoder_lengths, seq_lengths)):
            joint_hidden_states[i, :encoder_seq_len] = instruct_hidden_states[i, :encoder_seq_len]
            joint_hidden_states[i, encoder_seq_len:seq_len] = img_hidden_states[i, : seq_len - encoder_seq_len]

        # Single-stream stage.
        hidden_states = joint_hidden_states
        for layer in self.single_stream_layers:
            hidden_states = layer(hidden_states, joint_attention_mask, rotary_emb, temb)

        # Output projection.
        hidden_states = self.norm_out(hidden_states, temb)

        # Extract this rank's noise-image shard and gather it once.
        local_img_output = hidden_states.new_zeros(
            batch_size,
            img_mask.shape[1],
            hidden_states.shape[-1],
        )
        for i, (img_len, seq_len) in enumerate(zip(local_img_lengths, seq_lengths)):
            local_img_output[i, :img_len] = hidden_states[i, seq_len - img_len : seq_len]

        image_tokens = self.sp_gather_boundary(local_img_output)

        # Reshape back to image format.
        p = self.patch_size
        output = []
        for i, (img_size, img_len) in enumerate(zip(img_sizes, global_img_lengths)):
            height, width = img_size
            img_tokens = image_tokens[i, :img_len]
            img_output = rearrange(
                img_tokens,
                "(h w) (p1 p2 c) -> c (h p1) (w p2)",
                h=height // p,
                w=width // p,
                p1=p,
                p2=p,
            )
            output.append(img_output)

        if is_hidden_states_tensor:
            output = torch.stack(output, dim=0)

        return output

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        """Load diffusers-named checkpoint weights into the native module.

        Name promotions relative to upstream (see step 8/10 findings):

        - ``*.img_instruct_attn.processor.{img,instruct}_{to_q,to_k,to_v}`` /
          ``{instruct,img}_out`` -> drop ``.processor`` (upstream keeps the
          joint-attention projections on the attention processor; the native
          module hosts them directly).
        - ``*.to_out.0.weight`` -> ``*.to_out.weight`` (diffusers wraps the
          output projection in a ``ModuleList``; the native module uses a plain
          linear).

        Packed Q/K/V and FFN gate/input matrices are folded onto the fused
        ``QKVParallelLinear`` / ``MergedColumnParallelLinear`` parameters using
        :attr:`stacked_params_mapping` — the same mapping loader consumers such
        as LoRA discovery and quantized weight loaders read.

        A fused parameter is only reported as loaded once *every* one of its
        source matrices has arrived. The caller compares parameter names, so
        reporting e.g. ``to_qkv`` complete after the first shard would let a
        checkpoint carrying only ``to_q`` start up with the ``k``/``v`` slices
        left uninitialized.
        """
        stacked_params_mapping = self.stacked_params_mapping
        # The shard ids each fused parameter is assembled from, keyed by the
        # mapping entry that produces it.
        expected_shards: dict[str, set[str | int]] = defaultdict(set)
        for param_name, _weight_name, packed_shard_id in stacked_params_mapping:
            expected_shards[param_name].add(packed_shard_id)

        params_dict = dict(self.named_parameters())
        loaded_params: set[str] = set()
        # Fused parameter -> (mapping entry that produced it, shards received).
        fused_params: dict[str, tuple[str, set[str | int]]] = {}

        for name, loaded_weight in weights:
            original_name = name
            if ".img_instruct_attn.processor." in name:
                name = name.replace(".img_instruct_attn.processor.", ".img_instruct_attn.")
            if ".to_out.0." in name:
                name = name.replace(".to_out.0.", ".to_out.")

            shard_id: str | int | None = None
            matched_entry: str | None = None
            for param_name, weight_name, packed_shard_id in stacked_params_mapping:
                if weight_name in name:
                    name = name.replace(weight_name, param_name)
                    shard_id = packed_shard_id
                    matched_entry = param_name
                    break

            if name not in params_dict:
                logger.warning("Skipping unexpected checkpoint weight %s", original_name)
                continue

            param = params_dict[name]
            weight_loader = getattr(param, "weight_loader", default_weight_loader)
            if matched_entry is None:
                weight_loader(param, loaded_weight)
            else:
                weight_loader(param, loaded_weight, shard_id)
                _, received = fused_params.setdefault(name, (matched_entry, set()))
                received.add(shard_id)
            loaded_params.add(name)

        # Withdraw any fused parameter that only received part of its source
        # matrices, so the caller's "not initialized from checkpoint" check
        # reports it as missing instead of accepting a half-filled parameter.
        for name, (matched_entry, received) in fused_params.items():
            if received != expected_shards[matched_entry]:
                loaded_params.discard(name)

        unloaded_params = sorted(params_dict.keys() - loaded_params)
        if unloaded_params:
            logger.warning("Model parameters not loaded from checkpoint: %s", unloaded_params)

        return loaded_params
