# Ring attention backend components
